# Angry Birds clone

Angry Birds clone game in JavaScript.

![alt screenshot](https://raw.githubusercontent.com/lrusso/AngryBirds/master/AngryBirds.png)

## Web:

https://lrusso.github.io/AngryBirds/AngryBirds.htm

## Disclaimer

The Angry Birds resources (images, fonts, music and sounds) are provided for educational purposes ONLY. This demo is not affiliated with or endorsed by their respective copyright holders.
